<?php
namespace App\Test\TestCase\Controller;

use App\Controller\MenuController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\MenuController Test Case
 */
class MenuControllerTest extends IntegrationTestCase
{

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.menu'
    ];

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}

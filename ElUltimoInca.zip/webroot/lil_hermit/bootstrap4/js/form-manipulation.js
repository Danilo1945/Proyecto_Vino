jQuery(function () {

    // Currently intentionally blank as we don't need any js manipulation of forms
});
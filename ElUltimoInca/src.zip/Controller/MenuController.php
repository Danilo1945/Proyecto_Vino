<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Menu Controller
 *
 */
class MenuController extends AppController
{
    public function index()
    {
       
    }
    public function index1()
    {
       
    }
     public function home()
    {
       
    }
     public function acercaDe ()
    {
       
    }
     public function catalogo ()
    {
       
    }
     public function contactos()
    {
       
    }
     public function pedidos ()
    {
       
    }
}
